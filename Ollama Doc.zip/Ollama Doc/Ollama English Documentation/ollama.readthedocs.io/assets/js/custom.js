document.addEventListener("DOMContentLoaded", function () {
  console.log('i am ollama')
  var _hmt = _hmt || [];
  (function() {
    var hm = document.createElement("script");
    hm.src = "https://hm.baidu.com/hm.js?be62e5d1e814e52f3375a7a6f042b6ff";
    var s = document.getElementsByTagName("script")[0]; 
    s.parentNode.insertBefore(hm, s);
  })();
})